#!/bin/bash
java -jar vam.jar
